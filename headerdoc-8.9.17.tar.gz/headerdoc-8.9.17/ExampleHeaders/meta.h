/*! @header copytest
    @copyright Apple Computer
    @meta http-equiv="refresh" content="1;http://www.apple.com/"
 */

/*! @function copyfunc
  This is a pointless function
 */

int copyfunc(int a);

